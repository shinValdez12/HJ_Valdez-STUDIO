1:"$Sreact.fragment"
2:I[78602,["/_next/static/chunks/04dfmenzx6x5b.js","/_next/static/chunks/17a0wek~8u9qr.js"],"ViewportBoundary"]
3:I[78602,["/_next/static/chunks/04dfmenzx6x5b.js","/_next/static/chunks/17a0wek~8u9qr.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[4810,["/_next/static/chunks/04dfmenzx6x5b.js","/_next/static/chunks/17a0wek~8u9qr.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Workforce Management | SaaS Demo"}],["$","meta","1",{"name":"description","content":"Hybrid Workforce Management Platform - Attendance, Scheduling, Leave Management"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.0x3dzn~oxb6tn.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","3",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"HPzd9nJpcSYdJxSJ277GL"}
