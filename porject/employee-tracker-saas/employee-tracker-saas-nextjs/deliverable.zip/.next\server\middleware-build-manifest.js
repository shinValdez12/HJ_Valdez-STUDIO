globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/HPzd9nJpcSYdJxSJ277GL/_buildManifest.js",
    "static/HPzd9nJpcSYdJxSJ277GL/_ssgManifest.js",
    "static/HPzd9nJpcSYdJxSJ277GL/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0o3-zhhm~mj4l.js",
    "static/chunks/0-f4hs._pnjeb.js",
    "static/chunks/085381wnl~bez.js",
    "static/chunks/0n_bo8lpxfr8q.js",
    "static/chunks/turbopack-0vn6dmnby9io2.js"
  ]
};
