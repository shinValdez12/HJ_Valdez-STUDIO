var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/[root-of-the-server]__0zrejzh._.js")
R.c("server/chunks/_next-internal_server_app_favicon_ico_route_actions_095lj93.js")
R.m(99374)
module.exports=R.m(99374).exports
