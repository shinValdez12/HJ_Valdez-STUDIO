module.exports=[66846,a=>{"use strict";var b=a.i(27712),c=a.i(16046);a.s(["useRegisteredLabelId",0,function(a,d){let e=(0,c.useBaseUiId)(a);return(0,b.useIsoLayoutEffect)(()=>(d(e),()=>{d(void 0)}),[e,d]),e}])}];

//# sourceMappingURL=0gq~_%40base-ui_react_esm_utils_useRegisteredLabelId_0nx2x_~.js.map