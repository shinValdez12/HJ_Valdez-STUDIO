module.exports=[47728,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_calendar_page_actions_12hmj_-.js.map