module.exports=[97905,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_positions_page_actions_01ddtuj.js.map